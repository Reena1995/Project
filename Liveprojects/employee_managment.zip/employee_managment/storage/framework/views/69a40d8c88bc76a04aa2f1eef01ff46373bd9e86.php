<!DOCTYPE html>
<html lang="en" data-theme="light">
    <head>
        <meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" name="viewport" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-touch-fullscreen" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <title>Dashboard | Admin Portal</title>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('console/assets/img/favicon.png')); ?>" />
        <link rel="icon" href="<?php echo e(asset('console/assets/img/favicon.png')); ?>" type="image/png" sizes="16x16" />
        <!--PAGE-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/js/jquery-scrollbar/jquery.scrollbar.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('console/assets/js/jquery-ui/jquery-ui.min.css')); ?>" />
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,600" rel="stylesheet" />
        <!--Material Icons-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/fonts/materialdesignicons/materialdesignicons.min.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/css/font-awesome.min.css')); ?>" />
        <!--Page Specific CSS-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/js/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/js/DataTables/datatables.min.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/js/select2/css/select2.min.css')); ?>" />
        <!--Hci Admin CSS-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/css/tbs.css')); ?>" />
        <!-- Additional library for page -->
    </head>
    <!--body with default sidebar pinned -->

    <body class="sidebar-pinned">
       
			  <?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <main class="admin-main">
           
             <?php echo $__env->make('admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php $__currentLoopData = ['error','success']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($msg)): ?>
                    <div class="alert alert-<?php echo e($msg); ?>" role="alert">
                    <?php echo e(session::get($msg)); ?>

                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->yieldContent('content'); ?>
            
        </main>
		 <?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</html>
<?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/common/master.blade.php ENDPATH**/ ?>