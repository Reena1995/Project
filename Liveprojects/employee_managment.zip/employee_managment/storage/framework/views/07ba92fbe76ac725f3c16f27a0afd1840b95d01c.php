<?php $__env->startSection('content'); ?>
            <section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container"></div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
       	<?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>
 
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('Console.Common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/Console/Modules/dashboard.blade.php ENDPATH**/ ?>