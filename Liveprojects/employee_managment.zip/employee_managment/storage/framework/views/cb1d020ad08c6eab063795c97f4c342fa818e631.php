<!DOCTYPE html>
<html lang="en" data-theme="light">
    <head>
        <meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" name="viewport" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-touch-fullscreen" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <title>Dashboard | Admin Portal</title>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('console/assets/img/favicon.png')); ?>" />
        <link rel="icon" href="<?php echo e(asset('console/assets/img/favicon.png')); ?>" type="image/png" sizes="16x16" />
        <!--PAGE-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/js/jquery-scrollbar/jquery.scrollbar.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('console/assets/js/jquery-ui/jquery-ui.min.css')); ?>" />
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,600" rel="stylesheet" />
        <!--Material Icons-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/fonts/materialdesignicons/materialdesignicons.min.css')); ?>" />
        <!--Hci Admin CSS-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('console/assets/css/tbs.css')); ?>" />
        <!-- Additional library for page -->
    </head>
    <!--body with default sidebar pinned -->

    <body class="sidebar-pinned">
       
			  <?php echo $__env->make('Console.Partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <main class="admin-main">
           
             <?php echo $__env->make('Console.Partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->yieldContent('content'); ?>
            
        </main>
		 <?php echo $__env->make('Console.Partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/Console/Common/master.blade.php ENDPATH**/ ?>