@extends('layout.master')
@section('content')
            <section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container">employee panel</div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
       	@endsection
 @section('script')
 
 @endsection
