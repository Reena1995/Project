
        <script src="{{asset('console/assets/js/jquery/jquery.min.js')}}"></script>
        <script src="{{asset('console/assets/js/jquery-ui/jquery-ui.min.js')}}"></script>
        <script src="{{asset('console/assets/js/popper/popper.js')}}"></script>
        <script src="{{asset('console/assets/js/bootstrap/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('console/assets/js/jquery-scrollbar/jquery.scrollbar.min.js')}}"></script>
        <script src="{{asset('console/assets/js/tbs.js')}}"></script>
        <script scr="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.js"></script>
        <script scr="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
        <!-- <script>
            $(document).ready(function () {
                $(".theme-date-picker").datepicker();
            });
        </script> -->