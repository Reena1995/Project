
        <script src="{{asset('console/assets/js/jquery/jquery.min.js')}}"></script>
        <script src="{{asset('console/assets/js/jquery-ui/jquery-ui.min.js')}}"></script>
        <script src="{{asset('console/assets/js/popper/popper.js')}}"></script>
        <script src="{{asset('console/assets/js/bootstrap/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('console/assets/js/jquery-scrollbar/jquery.scrollbar.min.js')}}"></script>
        <script src="{{asset('console/assets/js/tbs.js')}}"></script>
        <script>
            $(document).ready(function () {
                $(".theme-date-picker").datepicker();
            });
        </script>