@extends('Console.Common.master')
@section('content')
            <section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container"></div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
       	@endsection
 @section('script')
 
 @endsection
