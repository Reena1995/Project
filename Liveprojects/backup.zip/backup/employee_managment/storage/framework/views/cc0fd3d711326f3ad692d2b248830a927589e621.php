

<form  id="emp_asset_deatil_add"  name="emp_asset_deatil_add" action="<?php echo e(route('organization.asset.add')); ?>"  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">

            <div id="assetformId">
                <?php if(count($emp_asset_details)): ?>
                    <?php $__currentLoopData = $emp_asset_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card education mt-3 assetadd">
                
                            <div class="card-body " >
            
                                    <div class="form-row">
                                
                                        <input type="hidden" name="asset_uuid[]" value="<?php echo e($asset->uuid); ?>">

                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                            <label>Asset brand</label>
                                            <select class="form-control" name="asset_brand_id[]">
                                            <?php $__currentLoopData = $asset_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($brand->id); ?>"<?php echo e($asset->asset_brand_id  == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?> </option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('asset_brand_id[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('asset_brand_id[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                            <label>Asset Sub Type Brand</label>
                                            <select class="form-control" name="asset_sub_type_id[]">
                                                <?php $__currentLoopData = $asset_sub_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                                    <option value="<?php echo e($sub->id); ?>" <?php echo e($asset->asset_sub_type_id == $sub->id ? 'selected' : ''); ?>><?php echo e($sub->type); ?> </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('asset_sub_type_id[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('asset_sub_type_id[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Serial No</label>
                                            <input type="text" value = "<?php echo e($asset->serial_no); ?>" name="serial_no[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('serial_no[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('serial_no[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Purchased Date</label>
                                            <input type="date" value = "<?php echo e($asset->purchased_dn); ?>" name="purchased_dn[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('purchased_dn[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('purchased_dn[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Purchased From</label>
                                            <input type="text" value = "<?php echo e($asset->purchased_from); ?>" name="purchased_from[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('purchased_from[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('purchased_from[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Warranty Period</label>
                                            <input type="text" value = "<?php echo e($asset->warranty_period); ?>" name="warranty_period[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('warranty_period[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('warranty_period[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Organization Asset Code</label>
                                            <input type="text" value = "<?php echo e($asset->organization_asset_code); ?>" name="organization_asset_code[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('organization_asset_code[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('organization_asset_code[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Invoice No</label>
                                            <input type="text" value = "<?php echo e($asset->invoice_no); ?>" name="invoice_no[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('invoice_no[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('invoice_no[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                       

                                        
                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <?php if(empty($asset)): ?>
                                            <lable >Asset Image</lable>
                                            <input type="file" name="asset_image[]" class=" form-control form-control-lg">
                                            <?php else: ?>
                                            <lable >Result</lable>
                                            <input type="file" name="asset_image[]" class=" form-control form-control-lg">
                                            <div class="imageset mt-4 m-4">
                                                    <img src="<?php echo e(asset('console/upload/employee/assetimage/'.$asset->asset_image)); ?>" height="120px" width="100px"> 
                                            </div>   
                                            <?php endif; ?>
                                        </div>

                                        <?php if($errors->has('asset_image[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('asset_image[]')); ?></span>
                                         <?php endif; ?>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        </div>

                                    
                                    </div> 
                            </div>   
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?> 

                    <div class="card education mt-3 assetadd educationDetails" id="">
            
                        <div class="card-body " >
        
                                <div class="form-row">
                            
                               
                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                            <label>Asset brand</label>
                                            <select class="form-control" name="asset_brand_id[]">
                                            <?php $__currentLoopData = $asset_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?> </option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('asset_brand_id[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('asset_brand_id[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                            <label>Asset Sub Type Brand</label>
                                            <select class="form-control" name="asset_sub_type_id[]">
                                                <?php $__currentLoopData = $asset_sub_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                                    <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->type); ?> </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('asset_sub_type_id[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('asset_sub_type_id[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Serial No</label>
                                            <input type="text" value = "" name="serial_no[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('serial_no[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('serial_no[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Purchased Date</label>
                                            <input type="date"    value = "" name="purchased_dn[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('purchased_dn[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('purchased_dn[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Purchased From</label>
                                            <input type="text" value = "" name="purchased_from[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('purchased_from[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('purchased_from[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Warranty Period</label>
                                            <input type="text" value = "" name="warranty_period[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('warranty_period[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('warranty_period[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Organization Asset Code</label>
                                            <input type="text" value = "" name="organization_asset_code[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('organization_asset_code[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('organization_asset_code[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Invoice No</label>
                                            <input type="text" value = "" name="invoice_no[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('invoice_no[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('invoice_no[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <lable>Asset Image</lable>
                                        <input type="file" data-key="image_fill"  name="asset_image[]" class=" form-control form-control-lg">
                                    </div>
                                    <?php if($errors->has('asset_image[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('asset_image[]')); ?></span>
                                    <?php endif; ?>


                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                    </div> 

                                    <div>
                                        <button type="button" class="btn btn-danger d-none delete">delete</button> 
                                    </div>

                                </div> 
                        </div>   
                    </div>
                <?php endif; ?>     
            </div>
            
            <div class="mt-2"><button type="button" id="addd" class="btn btn-default pull-left  btn btn-primary mt-2 ">Add</button><br></div>

            <div class="form-card-footer card-footer p-t-20 p-0 text-right">
                    <div class="btn-group mr-3" role="group" aria-label="Second group">
                        <a href="" >
                            <button class="theme-btn-outline">cancel</button>
                        </a>
                    </div>
                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                        <button type="button"  id="assetbtn" class="theme-btn text-white">Save</button>
                    </div>
            </div>     


        </form>

   


<?php $__env->startPush('scripts'); ?>
 <script>
    $(document).ready(function () {

        $("#addd").click(function () { 

            console.log('adddddddd')

            var defaultHtmlAppend = $('.assetadd').last().clone();
            var rowIndex = $('.assetadd').length;  
            console.log(defaultHtmlAppend.find('.education'));

            defaultHtmlAppend.find('input[name]').each(function(){
                var name = $(this).attr('name');
		    	$(this).attr('name',name).val('');
                $(this).parents('.assetadd').find('.imageset').remove();
                $(this).attr('data-key',rowIndex);                  
                $(this).parents('.assetadd').append('');
		    }); 
            defaultHtmlAppend.find('input[type="file"]').each(function(){
                console.log("assrt call");
                // var name = $(this).attr('name');
		    	// $(this).attr('name',name).val('');
                // $(this).parents('.eduremove').find('.imageset').remove();
                $(this).attr('data-key','image_fill');
                // $(this).parents('.eduremove').append('');
		    });
          //  defaultHtmlAppend.hasClass('.assetadd').addClass('education_detail_'+rowIndex);
          defaultHtmlAppend.attr('id','educationDetail-'+rowIndex);

            defaultHtmlAppend.find('.btn-danger').removeClass('d-none').attr('data-id',rowIndex);
            $('#assetformId').append(defaultHtmlAppend);
        });



        $(document).delegate('.delete','click',function () { 
            var id = $(this).attr('data-id');

            $('#educationDetail-'+id).remove();
            
        });
          

    });
 </script>   
<?php $__env->stopPush(); ?>    <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/organization/asset.blade.php ENDPATH**/ ?>