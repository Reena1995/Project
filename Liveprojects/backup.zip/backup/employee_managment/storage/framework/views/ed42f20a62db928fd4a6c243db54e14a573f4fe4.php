
<form id="emp_location_id"  name="emp_location_id" action="<?php echo e(route('organization.location.add')); ?>"  method="post" enctype="multipart/form-data">
    <div class="form-row">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
        
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Company Location</label>
            <select class="form-control"  name="company_location_id">
                <option value="" selected="">Select Company Location</option>
                <?php $__currentLoopData = $company_location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>" <?php echo e((isset($emp_location_details) ? ($emp_location_details->company_location_id  == $location->id ? 'selected' : '') :  old('organization_role_id') == $location->id ? 'selected' : '' )); ?>><?php echo e($location->name); ?>  </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('company_location_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('company_location_id')); ?></span>
            <?php endif; ?>
        </div>
          
       
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Company Location Type</label>
            <select class="form-control"  name="company_location_type_id">
            <option value="" selected="">Select Location Type</option>
                <?php $__currentLoopData = $company_location_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>" <?php echo e((isset($emp_location_details) ? ($emp_location_details->company_location_type_id   == $type->id ? 'selected' : '') :  old('company_location_type_id ') == $type->id ? 'selected' : '' )); ?>><?php echo e($type->type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('company_location_type_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('company_location_type_id')); ?></span>
            <?php endif; ?>
        </div>
        
      
        
        <div class="form-card-footer card-footer p-t-20 p-0 text-right">
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <a href="" >
                    <button class="theme-btn-outline">cancel</button>
                </a>
            </div>
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <button type="submit"  value="submit" name="submit" class="theme-btn text-white">Save</button>
            </div>
        </div>        
    </div> 
</form>
<?php $__env->startPush('scripts'); ?>
 <script>
    
</script>
 <?php $__env->stopPush(); ?>   <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/organization/location.blade.php ENDPATH**/ ?>