<form id="document_deatil_add" name="document_deatil_add"  action="<?php echo e(route('personal.document.add')); ?>"  method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
       
     
        <?php if(count($empDocumentDetails)): ?>
             <?php $__currentLoopData = $empDocumentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empdoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                            <div class="form-row">

                                <input type="hidden" name="document_uuid[]" value="<?php echo e($empdoc->uuid); ?>"> 
                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Document Type</label>
                                    <input type="hidden" name="type[]"  value="<?php echo e($empdoc->documentName->id); ?>" >
                                    <input type="text"  value="<?php echo e($empdoc->documentName->type); ?>" class="form-control form-control-lg" readonly>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <div class="custom-file">
                                            <input type="file"  name="documents[]" class="" id="inputGroupFile02" >
                                             <div class="imageset mt-4 m-4">
                                                <img src="<?php echo e(asset('console/upload/employee/document/'.$empdoc->file)); ?>" height="120px" width="100px"> 
                                            </div> 
                                    </div>        
                                    
                                </div>


                            </div>
                           
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php else: ?>  
            
            <?php if(count($document)): ?>
                            <?php $__currentLoopData = $document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-row">
                          
                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">

                                    <label>Document Type</label>
                                    <input type="hidden" name="type[]"  value="<?php echo e($doc->id); ?>" >
                                    <input type="text"   value="<?php echo e($doc->type); ?>" class="form-control form-control-lg" readonly>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <div class="custom-file">
                                            <input type="file" value="" data-key="doc_image" name="documents[]"  id="inputGroupFile02" >
                                    </div>
                                    <?php if($errors->has('documents[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('documents[]')); ?></span>
                                    <?php endif; ?>
                                    
                                </div>


                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>     
        <?php endif; ?> 

        <div class="form-card-footer card-footer p-t-20 p-0 text-right">
                    <div class="btn-group mr-3" role="group" aria-label="Second group">
                        <a href="" >
                            <button class="theme-btn-outline">cancel</button>
                        </a>
                    </div>
                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                        <button type="button"  id="doctBtn"  class="theme-btn text-white">Save</button>
                    </div>
            </div>    




      
</form>

<?php $__env->startPush('scripts'); ?>
 <script>
    
</script>
 <?php $__env->stopPush(); ?>   <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/personal/document.blade.php ENDPATH**/ ?>