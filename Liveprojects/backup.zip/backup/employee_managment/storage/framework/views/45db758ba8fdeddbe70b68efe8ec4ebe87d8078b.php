

<form  id="emp_proessional_add"  name="emp_proessional_add" action="<?php echo e(route('professional.professional.add')); ?>"  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">

            <div id="emp_prof_add">

                <?php if(count($emp_professional_details)): ?>
                
                    <?php $__currentLoopData = $emp_professional_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card education mt-3 profeadd">
                
                            <div class="card-body " >
            
                                    <div class="form-row">
                                
                                        <input type="hidden" name="professional_uuid[]" value="<?php echo e($professional->uuid); ?>">

                                        

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Name Of The Institute</label>
                                            <input type="text" value = "<?php echo e($professional->name_of_institute); ?>" name="name_of_institute[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('name_of_institute[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('name_of_institute[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>To</label>
                                            <input type="date" name="to[]"  value = "<?php echo e($professional->to); ?>"  class="form-control form-control-lg" placeholder="Select Date Of Birth">
                                            <?php if($errors->has('to[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('to[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>From</label>
                                            <input type="date" value = "<?php echo e($professional->from); ?>" name="from[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('from[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('from[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Address</label>
                                            <textarea  class="form-control form-control-lg"  name="address[]" cols="30" placeholder="Enter Details Of disaility">
                                                    <?php echo e($professional->address); ?>

                                            </textarea>
                                            <?php if($errors->has('address[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('address[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Description</label>
                                            <textarea  class="form-control form-control-lg"  name="description[]" cols="30" placeholder="Enter Details Of disaility">
                                                <?php echo e($professional->description); ?>

                                            </textarea>
                                            <?php if($errors->has('description[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('description[]')); ?></span>
                                            <?php endif; ?>
                                        </div>


                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <?php if(empty($professional)): ?>
                                                <lable >Certificate</lable>
                                                <input type="file" name="certificate_pdf[]" class=" form-control form-control-lg">
                                            <?php else: ?>
                                                <lable >Certificate</lable>
                                                <input type="file" name="certificate_pdf[]" class=" form-control form-control-lg">
                                                <div class="imageset mt-4 m-4">
                                                        <img src="<?php echo e(asset('console/upload/employee/profession_training/'.$professional->certificate_pdf)); ?>" height="120px" width="100px"> 
                                                </div>   
                                            <?php endif; ?>
                                        </div>

                                        <?php if($errors->has('certificate_pdf[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('certificate_pdf[]')); ?></span>
                                         <?php endif; ?>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        </div>

                                    
                                    </div> 
                            </div>   
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?> 

                    <div class="card education mt-3 profeadd educationDetails" id="">
            
                        <div class="card-body " >
        
                            <div class="form-row">
                            
                              
                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Name Of The Institute</label>
                                    <input type="text" value = "" name="name_of_institute[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                    <?php if($errors->has('name_of_institute[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('name_of_institute[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>To</label>
                                    <input type="date" name="to[]"  value = ""  class="form-control form-control-lg" placeholder="Select Date Of Birth">
                                    <?php if($errors->has('to[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('to[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>From</label>
                                    <input type="date" value = "" name="from[]"class="form-control form-control-lg" placeholder="Enter University Name">
                                    <?php if($errors->has('from[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('from[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Address</label>
                                    <textarea  class="form-control form-control-lg"   name="address[]" cols="30" placeholder="Enter Details Of disaility"></textarea>
                                    <?php if($errors->has('address[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('address[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Description</label>
                                    <textarea  class="form-control form-control-lg"  value="" name="description[]" cols="30" placeholder="Enter Details Of disaility"></textarea>
                                    <?php if($errors->has('description[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('description[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <lable>certificate</lable>
                                    <input type="file" data-key="certificate_image"  name="certificate_pdf[]" class=" form-control form-control-lg">
                                </div>
                                <?php if($errors->has('certificate_pdf[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('certificate_pdf[]')); ?></span>
                                <?php endif; ?>


                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    
                                </div> 

                                <div>
                                    <button type="button"  class="btn btn-danger d-none delete">delete</button> 
                                </div>

                            </div> 

                        </div>   
                       
                    </div>
                  

                   
                <?php endif; ?>  
                
                
            </div>
           
            <div class="mt-4"><button type="button" id="addprofe" class="btn btn-default pull-left  btn btn-primary mt-2 ">Add</button><br></div>
           
            
            <div class="form-card-footer card-footer p-t-20 p-0 text-right">
                    <div class="btn-group mr-3" role="group" aria-label="Second group">
                        <a href="" >
                            <button class="theme-btn-outline">cancel</button>
                        </a>
                    </div>
                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                        <button type="button" id="profBtn"   class="theme-btn text-white">Save</button>
                    </div>
            </div>     


        </form>

   


<?php $__env->startPush('scripts'); ?>
 <script>
    $(document).ready(function () {

        $("#addprofe").click(function () { 

            console.log('addprofeddddd');

            var defaultHtmlAppend = $('.profeadd').last().clone();
            console.log(defaultHtmlAppend);
            var rowIndex = $('.profeadd').length;  
            console.log(defaultHtmlAppend.find('.education'));

            defaultHtmlAppend.find('input[name]').each(function(){
                var name = $(this).attr('name');
		    	$(this).attr('name',name).val('');
                $(this).parents('.profeadd').find('.imageset').remove();
                $(this).attr('data-key',rowIndex);                   
                $(this).parents('.profeadd').append('');
		    }); 
            defaultHtmlAppend.find('input[type="file"]').each(function(){
                console.log('file');
                var name = $(this).attr('name');
		    	// $(this).attr('name',name).val('');
                // $(this).parents('.eduremove').find('.imageset').remove();
                $(this).attr('data-key','certificate_image');
                // $(this).parents('.eduremove').append('');
		    }); 
            defaultHtmlAppend.find('textarea').each(function(){
                console.log('textaaaaa');
                var name = $(this).attr('name');
                $(this).attr('name',name).val('');
		    	
                $(this).attr('data-key','certificate_image');
                // $(this).parents('.eduremove').append('');
		    }); 
         
          defaultHtmlAppend.attr('id','educationDetail-'+rowIndex);

            defaultHtmlAppend.find('.btn-danger').removeClass('d-none').attr('data-id',rowIndex);
            $('#emp_prof_add').append(defaultHtmlAppend);
        });

        $(document).delegate('.delete','click',function () { 
            var id = $(this).attr('data-id');

            $('#educationDetail-'+id).remove();
            
        });
          

    });
 </script>   
<?php $__env->stopPush(); ?>    <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/professional/professional.blade.php ENDPATH**/ ?>