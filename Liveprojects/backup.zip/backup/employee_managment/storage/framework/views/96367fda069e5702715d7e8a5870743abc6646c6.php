<form id="personalDetailForm"  name="personal_deatil_add" action="<?php echo e(route('personal.personaldetail.add')); ?>"  method="post" enctype="multipart/form-data">
    <div class="form-row">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Father's Name </label>
            <input type="text" name="fathername"  value = "<?php echo e((isset($personal_detail) ? $personal_detail->fathername :  old('fathername'))); ?>" class="form-control form-control-lg" placeholder="Enter Father Name" tabindex="1" autofocus >
            <?php if($errors->has('fathername')): ?>
                <span class="errr-validation"><?php echo e($errors->first('fathername')); ?></span>
            <?php endif; ?>
        </div>  
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Mother's Name</label>
            <input type="text" name="mothername"  value = "<?php echo e((isset($personal_detail) ? $personal_detail->mothername :  old('mothername'))); ?>" class="form-control form-control-lg" placeholder="Enter Mother Name" tabindex="2">
            <?php if($errors->has('mothername')): ?>
                <span class="errr-validation"><?php echo e($errors->first('mothername')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Date Of Birth</label>
            <input type="date" name="dob"  value = "<?php echo e((isset($personal_detail) ? $personal_detail->dob :  old('dob'))); ?>" class="form-control form-control-lg" placeholder="Select Date Of Birth" tabindex="3">
            <?php if($errors->has('dob')): ?>
                <span class="errr-validation"><?php echo e($errors->first('dob')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group col-lg-6 col-md-6 col-sm-12 gender">
            <label class="">Gender</label>
            <div class="d-flex row ">
                <div class="custom-control custom-radio col-lg-2 col-md-4 col-6">
                    <input type="radio" name="gender" id="gender_male" tabindex="4" value="Male" class="custom-control-input" <?php if((old('gender') == 'Male') || (isset($personal_detail) && ($personal_detail->gender == 'Male'))): ?> checked <?php endif; ?>>
                    <label class="custom-control-label" for="gender_male">Male</label>
                </div>
                <div class="custom-control custom-radio col-lg-2 col-md-4 col-6">
                    <input type="radio"  name="gender" tabindex="4" id="gender_female" value="Female"  class="custom-control-input" <?php if((old('gender') == 'Female') || (isset($personal_detail) && ($personal_detail->gender == 'Female'))): ?> checked <?php endif; ?>>
                    <label class="custom-control-label" for="gender_female">Female</label>
                </div>
            </div>
            <?php if($errors->has('gender')): ?>
                <span class="errr-validation"><?php echo e($errors->first('gender')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Blood Group</label>
            <input type="text" name="bloodgroup"  tabindex="5" value = "<?php echo e((isset($personal_detail) ? $personal_detail->blood_group :  old('bloodgroup'))); ?>"   class="form-control form-control-lg" placeholder="Enter Blood Group">
            <?php if($errors->has('bloodgroup')): ?>
                <span class="errr-validation"><?php echo e($errors->first('bloodgroup')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Alternate Number</label>
            <input type="text" name="alternateno"  tabindex="6" value = "<?php echo e((isset($personal_detail) ? $personal_detail->alternate_no :  old('alternateno'))); ?>" class="form-control form-control-lg" placeholder="Enter alternate  Number">
            <?php if($errors->has('alternateno')): ?>
                <span class="errr-validation"><?php echo e($errors->first('alternateno')); ?></span>
            <?php endif; ?>
        </div>
        
        
        
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Marital Status </label>
            <select class="form-control" id="merriedstatus" value=""  name="marital_status"  tabindex="7">
                <!-- <option value= "" selected="">Choose...</option> -->
                <option value="single" <?php echo e((isset($personal_detail) ? ($personal_detail->marital_status == 'single' ? 'selected' : '') :  old('marital_status') == 'single' ? 'selected' : '' )); ?> >Single</option>
                <option value="married" <?php echo e((isset($personal_detail) ? ($personal_detail->marital_status == 'married' ? 'selected' : '') :  old('marital_status') == 'married' ? 'selected' : '' )); ?> >Married</option>
                <option value="divorce" <?php echo e((isset($personal_detail) ? ($personal_detail->marital_status == 'divorce' ? 'selected' : '') :  old('marital_status') == 'divorce' ? 'selected' : '' )); ?> >Divorce</option>
            </select>
            <?php if($errors->has('marital_status')): ?>
                <span class="errr-validation"><?php echo e($errors->first('marital_status')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group col-lg-6 col-md-6 col-sm-12 ">
            <div class="custom-file">
                <label class="custom-file-label" for="inputGroupFile02">Choose Profile Image</label>
                <?php if(empty($personal_detail)): ?>
                <input type="file" name="image"  tabindex="8" class="custom-file-input" id="inputGroupFile02" accept="image/png, image/gif, image/jpeg">
                
                <div class="file mt-2">
                    <span id="img-error" class="errr-validation">
                        <?php if($errors->has('image')): ?>
                            <?php echo e($errors->first('image')); ?>

                         <?php endif; ?>
                    </span>
                </div>   
                <?php else: ?>
                    <input type="file" name="image"tabindex="8"  class="custom-file-input" id="inputGroupFile02" accept="image/png, image/gif, image/jpeg">
                    
                    <div class="file mt-2">
                        <?php if($errors->has('image')): ?>
                        <span class="errr-validation"><?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                    </div>    
                    <div class="imageset mt-4 m-4">
                        <img src="<?php echo e(asset('console/upload/employee/profileimage/'.$personal_detail->image)); ?>" height="120px" width="100px"> 
                    </div>    
                <?php endif; ?>    
                
            </div>
        </div>
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Current Residence Type</label>
            <select class="form-control"  name="residencetype" tabindex="9">
            <option value="" selected="">Select Choose</option>
                <?php $__currentLoopData = $current_residency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  
                <option value="<?php echo e($curr->id); ?>" <?php echo e((isset($personal_detail) ? ($personal_detail->current_residence_type_id == $curr->id ? 'selected' : '') :  old('residencetype') == $curr->id ? 'selected' : '' )); ?>><?php echo e($curr->type); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('residencetype')): ?>
                <span class="errr-validation"><?php echo e($errors->first('residencetype')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Mode Of Transportation</label>
            <select class="form-control" value="<?php echo e(old('transportationmode')); ?>" name="transportationmode" tabindex="10">
            <option value="" selected="">Select Choose</option>
                <?php $__currentLoopData = $mode_transportation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mode->id); ?>" <?php echo e((isset($personal_detail) ? ($personal_detail->	mode_of_transportation_id  == $mode->id ? 'selected' : '') :  old('transportationmode') == $mode->id ? 'selected' : '' )); ?>><?php echo e($mode->type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('transportationmode')): ?>
                <span class="errr-validation"><?php echo e($errors->first('transportationmode')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Details Of Disability</label>
            <textarea  class="form-control form-control-lg" tabindex="11" name="disabilitydtls" cols="30" placeholder="Enter Details Of disaility">
                <?php echo e((isset($personal_detail) ? $personal_detail->details_of_disability :  old('disabilitydtls'))); ?>

            </textarea>
            <?php if($errors->has('disabilitydtls')): ?>
                <span class="errr-validation"><?php echo e($errors->first('disabilitydtls')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Total Experience</label>
            <input type="number" name="totalexperience" tabindex="12" value = "<?php echo e((isset($personal_detail) ? $personal_detail->total_of_experience :  old('totalexperience'))); ?>" value="<?php echo e(old('totalexperience')); ?>" class="form-control form-control-lg" placeholder="Total Experience">
            <?php if($errors->has('totalexperience')): ?>
                <span class="errr-validation"><?php echo e($errors->first('totalexperience')); ?></span>
            <?php endif; ?>
        </div>

        <h5 class="font-weight-semibold p-t-20 m-b-20">Current Address</h5>

        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
           
        </div>

        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label for="inputAddress">Current Address</label>
            <textarea  rows="6" tabindex="13" name="current_address" class="form-control form-control-lg" id="inputAddress" placeholder="1234 Main St">
                  <?php echo e((isset($personal_detail) ? $personal_detail->current_address :  old('current_address'))); ?>

            </textarea>
            <?php if($errors->has('current_address')): ?>
                <span class="errr-validation"><?php echo e($errors->first('current_address')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Country</label>
            <select class="form-control" tabindex="14" id="current_country"  name="current_country">
                <option value="" selected="">Select Country</option>
                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>" <?php echo e((isset($personal_detail) ? ($personal_detail->current_country_id  == $con->id ? 'selected' : '') :  old('current_country') == $con->id ? 'selected' : '' )); ?>><?php echo e($con->name); ?>  </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('current_country')): ?>
                <span class="errr-validation"><?php echo e($errors->first('current_country')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>State</label>
            <select class="form-control" tabindex="15" value="" id="current_state"  name="current_state">
                
            </select>
            <?php if($errors->has('current_state')): ?>
                <span class="errr-validation"><?php echo e($errors->first('current_state')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>City</label>
            <select class="form-control" tabindex="16" id="current_city"  name="current_city">
                
                
            </select>
            <?php if($errors->has('current_city')): ?>
                <span class="errr-validation"><?php echo e($errors->first('current_city')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Pincode</label>
            <input type="text" tabindex="17" name="current_pincode" value = "<?php echo e((isset($personal_detail) ? $personal_detail->current_pincode :  old('current_pincode'))); ?>"  class="form-control form-control-lg" placeholder="Enter current pincode">
            <?php if($errors->has('current_pincode')): ?>
                <span class="errr-validation"><?php echo e($errors->first('current_pincode')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
           
        </div>

        <h5 class="font-weight-semibold p-t-20 m-b-20">Permanent Address</h5>
        
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
           
        </div>

        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label for="inputAddress2">Permanent Address</label>
            <textarea  rows="6"  tabindex="18" name="permanent_address"   class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
                <?php echo e((isset($personal_detail) ? $personal_detail->permanent_address :  old('permanent_address'))); ?>

            </textarea>
            <?php if($errors->has('permanent_address')): ?>
                <span class="errr-validation"><?php echo e($errors->first('permanent_address')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Country </label>
            <select class="form-control"  tabindex="19" id="permanent_country" name="permanent_country">
                <option value="" selected="">Select Country</option>
                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>" <?php echo e((isset($personal_detail) ? ($personal_detail->permanent_country_id  == $con->id ? 'selected' : '') :  old('current_country') == $con->id ? 'selected' : '' )); ?>><?php echo e($con->name); ?>  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('permanent_country')): ?>
                <span class="errr-validation"><?php echo e($errors->first('permanent_country')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>State</label>
            <select class="form-control"  tabindex="20" id="permanent_state"  name="permanent_state" >
                
                
            </select>
            <?php if($errors->has('permanent_state')): ?>
                <span class="errr-validation"><?php echo e($errors->first('permanent_state')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>City</label>
            <select class="form-control"id="permanent_city"  tabindex="21" name="permanent_city">
                
                    
            </select>
            <?php if($errors->has('permanent_city')): ?>
                <span class="errr-validation"><?php echo e($errors->first('permanent_city')); ?></span>
            <?php endif; ?>
        </div>
        
        
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Pincode</label>
            <input type="text" name="permanent_pincode"  tabindex="22" value = "<?php echo e((isset($personal_detail) ? $personal_detail->permanent_pincode :  old('permanent_pincode'))); ?>"  class="form-control form-control-lg" placeholder="Enter permanant pincode">
            <?php if($errors->has('permanent_pincode')): ?>
                <span class="errr-validation"><?php echo e($errors->first('permanent_pincode')); ?></span>
            <?php endif; ?>
        </div>
        
        <div class="form-card-footer card-footer p-t-20 p-0 text-right">
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <a href="" >
                    <button class="theme-btn-outline">cancel</button>
                </a>
            </div>
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <button type="submit"  id="personalDetailBtn" value="submit" name="submit" class="theme-btn text-white">Save</button>
            </div>
        </div>        
    </div> 
</form>
<?php $__env->startPush('scripts'); ?>
 <script>
    $(document).ready(function () {
        /* date picker code start*/ 
        $(".theme-date-picker").datepicker();
        /* date picker code end*/ 

      
       
         /* country select than after state fetch  code start*/ 

            var curentState =  '<?php echo e(old("current_state")); ?>' ? '<?php echo e(old("current_state")); ?>' : '<?php echo e($personal_detail->current_state_id ?? 0); ?>';
            var countryID = '<?php echo e(old("current_country")); ?>' ? '<?php echo e(old("current_country")); ?>' :'<?php echo e($personal_detail->current_country_id ?? 0); ?>'; 
            console.log('countryID ::',countryID);
            console.log('curentState ::',curentState);
             
            getStates(countryID,'current_state',curentState);
            
            var permentState =  '<?php echo e(old("permanent_state")); ?>' ? '<?php echo e(old("permanent_state")); ?>' : '<?php echo e($personal_detail->permanent_state_id ?? 0); ?>';
            var countryID =  '<?php echo e(old("permanent_country")); ?>' ? '<?php echo e(old("permanent_country")); ?>' : '<?php echo e($personal_detail->permanent_country_id ?? 0); ?>';
             getStates(countryID,'permanent_state',permentState);


            function getStates(countryId,place,stateId = '0') {
                $.ajax({
                    url:"<?php echo e(route('getstate')); ?>",
                    type: "GET",
                    data: {
                        cid: countryId
                    },
                    success: function(result) {
                        $.each(result.states, function (key, value) {
                            var selected = '';
                            if(stateId == value.id){
                                selected = 'selected'; 
                            }
                            $('#'+place).append('<option value="' + value.id + '" '+selected+'>' + value.name + '</option>');
                        });
                            
                    }
                });
            } 
            $('#current_country').on('change', function () {
                console.log('SDVsdvsdzv');
                var countryID = $(this).val();
                console.log(countryID);
                getStates(countryID,'current_state');
            });   
                
            $('#permanent_country').on('change', function () {
                console.log('SDVsdvsdzv');
                var countryID = $(this).val();
                console.log(countryID);
                getStates(countryID,'permanent_state');
            });  
                
         /* country select than after state fetch  code end */    
         
         /* state select than after city fetch  code start*/ 

            var curentCity ='<?php echo e(old("current_city")); ?>' ? '<?php echo e(old("current_city")); ?>' : '<?php echo e($personal_detail->current_city_id ?? 0); ?>'; 
            var stateID = '<?php echo e(old("current_state")); ?>' ? '<?php echo e(old("current_state")); ?>' : '<?php echo e($personal_detail->current_state_id  ?? 0); ?>'; 
           
            console.log('stateID ::',stateID);
            console.log('curentCity ::',curentCity);

            getCitys(stateID,'current_city',curentCity);


            
            var permentCity = '<?php echo e(old("permanent_city")); ?>' ? '<?php echo e(old("permanent_city")); ?>' : '<?php echo e($personal_detail->permanent_city_id  ?? 0); ?>'; 
            var stateID = '<?php echo e(old("permanent_state")); ?>' ? '<?php echo e(old("permanent_state")); ?>' : '<?php echo e($personal_detail->permanent_state_id ?? 0); ?>';  
            
            
            getCitys(stateID,'permanent_city',permentCity);


            function getCitys(stateID,place,cityId = '0') {
                $.ajax({
                    url:"<?php echo e(route('getcity')); ?>",
                    type: "GET",
                    data: {
                        sid: stateID
                    },
                    success: function(result) {
                        $.each(result.cities, function (key, value) {
                            var selected = '';
                            if(cityId == value.id){
                                selected = 'selected'; 
                            }
                            $('#'+place).append('<option value="' + value.id + '" '+selected+'>' + value.name + '</option>');
                        });
                            
                    }
                });
            } 
            $('#current_state').on('change', function () {
                console.log('rreena');
                var stateID = $(this).val();
                console.log(stateID);
                getCitys(stateID,'current_city');
            });   
                
            $('#permanent_state').on('change', function () {
                console.log('rity');
                var stateID = $(this).val();
                console.log(stateID);
                getCitys(stateID,'permanent_city');
            });  
                
         /* state select than after city fetch  code end */ 

          /*validation Frontend jquery start*/
        //   var isEditImage = '<?php echo e(!empty($personal_detail) && ($personal_detail->image)); ?>' ? 2:1; 
       

        //     $(document).delegate('#personalDetailBtn','click',function(){
        //         isImageValidation() 
        //         formSubmit();  
        //     });
        //     function isImageValidation(){
        //          console.log('isEditImage :',isEditImage);
        //         var img = $('#inputGroupFile02').val();
        //         var html = '';
        //         console.log('img ::',img);
        //         if(img == '' && (isEditImage == 1)){
        //             html = 'Please select image';
        //             $('#img-error').html(html);
        //             return false;
        //         }   
        //         $('#img-error').html(html);
        //         console.log(img);
        //         console.log('Html ::    ',html);
        //         return true;
        //     }
        //     function formSubmit(){
        //         console.log('asd');
        //         $("#personalDetailForm").validate({
        //             rules : {
        //                 fathername : "required",  
        //                 mothername : "required", 
        //                 dob : "required",  
        //                 gender : "required",    
        //                 bloodgroup : "required",  
        //                 alternateno : { required : true,
        //                     number:true,
        //                     minlength:10,
        //                     maxlength:10
        //                 },    
        //                 marital_status : "required",  
        //                 //image :  {extension:'jpg|jpeg|png|ico|bmp'},    
        //                 residencetype : "required",     
        //                 transportationmode : "required",    
        //                 disabilitydtls : "required",  
        //                 totalexperience : "required",
        //                 current_address : "required",  
        //                 permanent_address : "required", 
        //                 current_country : "required",  
        //                 permanent_country : "required",    
        //                 current_state : "required",  
        //                 permanent_state : "required",    
        //                 current_city : "required",  
        //                 permanent_city : "required",    
        //                 current_pincode : {required: true,number:true},  
        //                 permanent_pincode : {required: true,number:true},    
                        
        //             },
        //             messages : {
        //                 fathername : "Please Enter a fathername ",
        //                 mothername : "Please Enter  a mothername ",
        //                 dob : "Please select a date of birth ",
        //                 gender : "Please Select  a gender ",
        //                 bloodgroup : "Please Enter a bloodgroup ",
        //                 alternateno : {
        //                     required : "Please enter a Mobile Number.",
        //                     number:'Please enter valid Number.',
        //                     minlength : "Please enter at least 10 digit Number.",
        //                     maxlength : "Please enter at least 10 digit Number.",
        //                 },
        //                 marital_status : "Please Select a marital status ",
        //                // image : {extension:"only jpg ,jpeg ,pdf"},
        //                 residencetype : "Please Select a residencetype ",
        //                 transportationmode : "Please Select  a transportationmode ",
        //                 disabilitydtls : "Please Enter a disability details ",
        //                 totalexperience : "Please Enter a totalexperience ",  
        //                 current_address : "Please Enter a Address ",
        //                 permanent_address : "Please Enter  a Address ",
        //                 current_country : "Please Select a Country ",
        //                 permanent_country : "Please Select  a Country ",
        //                 current_state : "Please Select a State ",
        //                 permanent_state : "Please Select  a State ",
        //                 current_city : "Please Select  a City",
        //                 permanent_city : "Please Select  a City",
        //                 current_pincode :  {required: "Please Enter a pincode",number:"Please enter numbers Only"},
        //                 permanent_pincode :  {required: "Please Enter a pincode",number:"Please enter numbers Only"},
        //             },
        //             errorClass: "custom-error",
        //             errorElement: "span",
        //             errorPlacement: function(error, element) {
        //                 var placement = $(element).data('error');
        //                 console.log(element.attr("type"),'placement');
        //                 if((element.attr("type") == 'radio')){                       
        //                     $(element).parents('.gender').append(error)
        //                 }else if (element.attr("type") == 'file') {
        //                     $('.file').append(error)
        //                 } else {
        //                     error.insertAfter(element);
        //                 }
        //             },
        //             submitHandler : function(form){
        //                 if(!isImageValidation()){
        //                     return false;
        //                 }else{
        //                     form.submit();
        //                 }
        //             }
        //         });
        //     }

         /*validation Frontend jquery start*/

         
         
         /* state select than after city fetch  mansi code start*/
        

            // function citys(stateId,place) {
            //     console.log('state')
            //     $.ajax({
            //         url:"<?php echo e(route('getcity')); ?>",
            //         type: "GET",
            //         data: {
            //             sid: stateId
            //         },
            //         success: function(result) {
            //                 $('#'+place).html('<option value="<?php echo e(old('value.name')); ?>">Select City</option>');
            //                 $.each(result.cities, function (key, value) {
            //                     $('#'+place).append('<option value="' + value.id + '">' + value.name + '</option>');
            //                 });
                            
            //         }
            //     });
            // }

            // $('#current_state').on('change', function () {
            //         console.log('xxxxxx');
            //         var stateID = $(this).val();
            //         console.log(stateID);
            //         citys(stateID,'current_city');
            // });   

            // $('#permanent_state').on('change', function () {
            //     console.log('yyyyyyy');
            //     var stateID = $(this).val();
            //     console.log(stateID);
            //     citys(stateID,'permanent_city');
            // });  
         /* state select than after city fetch mansi code end*/

       

    });

</script>
 <?php $__env->stopPush(); ?>   <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/personal/personaldetail.blade.php ENDPATH**/ ?>