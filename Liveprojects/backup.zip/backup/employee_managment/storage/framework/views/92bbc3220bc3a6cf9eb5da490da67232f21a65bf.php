

<form  name="education_deatil_add" id="education_deatil_add" action="<?php echo e(route('personal.education.add')); ?>"  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
            <div id="formId">
                <?php if(count($educationDetails)): ?>
                    <?php $__currentLoopData = $educationDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educationDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card education mt-3 eduremove">
                
                            <div class="card-body " >
            
                                    <div class="form-row">
                                          
                                        <input type="hidden" name="education_uuid[]" value="<?php echo e($educationDetail->uuid); ?>">
                                        <div class="col-lg-6 col-md-6 col-sm-12 align-items-center">
                                            <div class="form-group floating-label show-label ">
                                                <label>Medium</label>
                                                <select class="form-control employee_medium" name="medium[]" tabindex="1">
                                                    <?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($me->id); ?>"<?php echo e($educationDetail->medium_instruction_id  == $me->id ? 'selected' : ''); ?>><?php echo e($me->name); ?> </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                            <label>Education Level</label>
                                            <select class="form-control employee_education" name="education[]"  tabindex="2"  >
                                                <?php $__currentLoopData = $educationlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                                                <option value="<?php echo e($edu->id); ?>" <?php echo e($educationDetail->education_level_id == $edu->id ? 'selected' : ''); ?>><?php echo e($edu->name); ?> </option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            
                                            <?php if($errors->has('education[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('education[]')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <label>universityname</label>
                                            <input type="text"  tabindex="3"  value = "<?php echo e($educationDetail->university_name); ?>"  name="universityname[]" class="form-control form-control-lg employee_university" placeholder="Enter University Name">
                                        </div>

                                        
                                            <?php if($errors->has('universityname[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('universityname[]')); ?></span>
                                            <?php endif; ?>
                                        
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>percentage</label>
                                            <input type="text"  tabindex="4"  name="percentage[]"  value = "<?php echo e($educationDetail->percentage); ?>" class="form-control form-control-lg employee_percentage" placeholder="Enter your Percentage">
                                            <span class="education_level"></span>
                                        </div>
                                        
                                        <?php if($errors->has('percentage[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('percentage[]')); ?></span>
                                            <?php endif; ?>
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <label>specialization</label>
                                            <input type="text"  tabindex="5"  name="specialization[]" value = "<?php echo e($educationDetail->specilaization); ?>" class="form-control form-control-lg" placeholder="Enter your Specialization">
                                        </div>
                                        <?php if($errors->has('specialization[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('specialization[]')); ?></span>
                                            <?php endif; ?>
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <label>passingyear</label>
                                            <input type="text"  tabindex="6" name="passingyear[]" value = "<?php echo e($educationDetail->passing_year); ?>"class=" form-control form-control-lg" placeholder="Enter your Passing Year">
                                        </div>
                                        <?php if($errors->has('passingyear[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('passingyear[]')); ?></span>
                                            <?php endif; ?>
                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <?php if(empty($educationDetail)): ?>
                                            <lable >Result</lable>
                                            <input type="file"  tabindex="7"  name="result[]" class=" form-control form-control-lg">
                                            <?php else: ?>
                                            <lable >Result</lable>
                                            <input type="file" name="result[]"  tabindex="7"  class=" form-control form-control-lg">
                                            <div class="imageset mt-4 m-4">
                                                    <img src="<?php echo e(asset('console/upload/employee/education/'.$educationDetail->result)); ?>" height="120px" width="100px"> 
                                            </div>   
                                            <?php endif; ?>
                                        </div>

                                        <?php if($errors->has('result[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('result[]')); ?></span>
                                            <?php endif; ?>
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        </div>

                                    
                                    </div> 
                            </div>   
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                    <div class="card education mt-3 eduremove educationDetails" id="">
            
                        <div class="card-body " >
        
                                <div class="form-row">
                            
        
                                    <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                        <label>Medium</label>
                                        <select class="form-control employee_medium" name="medium[]">
                                        <?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <option value="<?php echo e($me->id); ?>"><?php echo e($me->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                       
                                    </div>
                                    <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                        <label>Education Level</label>
                                        <select class="form-control" name="education[]">
                                            <?php $__currentLoopData = $educationlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    
                                            <option value="<?php echo e($edu->id); ?>"><?php echo e($edu->name); ?> </option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <?php if($errors->has('education[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('education[]')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <input type="text" name="universityname[]"class="form-control form-control-lg universityname" placeholder="Enter University Name">
                                    </div>
                                    <?php if($errors->has('universityname[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('universityname[]')); ?></span>
                                    <?php endif; ?>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    
                                        <input type="text" name="percentage[]"class="form-control form-control-lg" placeholder="Enter your Percentage">
                                    </div>
                                    <?php if($errors->has('percentage[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('percentage[]')); ?></span>
                                        <?php endif; ?>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        <input type="text" name="specialization[]" class="form-control form-control-lg" placeholder="Enter your Specialization">
                                    </div>
                                    <?php if($errors->has('specialization[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('specialization[]')); ?></span>
                                        <?php endif; ?>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        <input type="text" name="passingyear[]"class=" form-control form-control-lg" placeholder="Enter your Passing Year" >
                                    </div>
                                    <?php if($errors->has('passingyear[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('passingyear[]')); ?></span>
                                        <?php endif; ?>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        <lable>Result</lable>
                                        <input type="file" data-key="new_image" name="result[]" id="result_id"class="form-control form-control-lg" accept="image/png, image/gif, image/jpeg">
                                    </div>
                                    <?php if($errors->has('result[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('result[]')); ?></span>
                                        <?php endif; ?>
                                    <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                    </div> 
                                    <div class="">
                                        <button type="button" class="btn btn-danger d-none delete">delete</button> 
                                    </div>
                                </div> 
                        </div>   
                    </div>
                <?php endif; ?>     
            </div>
            
            <div class="mt-2"><button type="button" id="add" class="btn btn-default pull-left  btn btn-primary mt-2 ">Add</button><br></div>
            <div class="form-card-footer card-footer p-t-20 p-0 text-right">
                    <div class="btn-group mr-3" role="group" aria-label="Second group">
                        <a href="" >
                            <button class="theme-btn-outline">cancel</button>
                        </a>
                    </div>
                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                        <button type="submit"  id="educationDetailBtn"  class="theme-btn text-white">Save</button>
                    </div>
            </div>     


        </form>

   


<?php $__env->startPush('scripts'); ?>
 <script>
    $(document).ready(function () {
        $("#add").click(function () { 
            var defaultHtmlAppend = $('.eduremove').last().clone();
            var rowIndex = ($('.eduremove').length);
            var prevId =  (rowIndex - 1);  
            console.log(defaultHtmlAppend.find('.education'));
            defaultHtmlAppend.find('input[name]').each(function(){
                var name = $(this).attr('name');
		    	$(this).attr('name',name).val('');
                $(this).parents('.eduremove').find('.imageset').remove();
                $(this).attr('data-key',rowIndex);
                $(this).parents('.eduremove').append('');
		    }); 
            defaultHtmlAppend.find('input[type="file"]').each(function(){
                var name = $(this).attr('name');
		    	// $(this).attr('name',name).val('');
                // $(this).parents('.eduremove').find('.imageset').remove();
                $(this).attr('data-key','new_image');
                // $(this).parents('.eduremove').append('');
		    }); 
            defaultHtmlAppend.find('select[name]').each(function(){
                var name = $(this).attr('name');
		    	// $(this).attr('name',name).val(''); 
                $(this).attr('data-key','rowIndex');
                $(this).parents('.eduremove').append('');
		    }); 
            console.log('prevId :'+prevId);
           
           
            defaultHtmlAppend.attr('id','educationDetail-'+rowIndex);
            defaultHtmlAppend.find('.btn-danger').removeClass('d-none').attr('data-id',rowIndex);
            $('#formId').append(defaultHtmlAppend);
        });
        $(document).delegate('.delete','click',function () { 
            var id = $(this).attr('data-id');
            $('#educationDetail-'+id).remove();
            
        });
        
        
    /*validation Frontend jquery start*/
    });
 </script>  
 
 
<?php $__env->stopPush(); ?>    <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/personal/education.blade.php ENDPATH**/ ?>