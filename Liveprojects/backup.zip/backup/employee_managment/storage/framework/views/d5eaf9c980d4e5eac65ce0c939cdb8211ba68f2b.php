<form id="jobprofileform_id"  name="job_profile_add" action="<?php echo e(route('organization.jobprofile.add')); ?>"  method="post" enctype="multipart/form-data">
    <div class="form-row">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Conmpany Employee Id</label>
            <input type="text" name="company_employee_id"  value = "<?php echo e((isset($emp_job_profile) ? $emp_job_profile->company_employee_id :  old('company_employee_id'))); ?>"  class="form-control form-control-lg" placeholder="Enter company employee id">
            <?php if($errors->has('company_employee_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('company_employee_id')); ?></span>
            <?php endif; ?>
        </div>  

        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Company Employee Device Id</label>
            <input type="text" name="company_emp_device_id"  value = "<?php echo e((isset($emp_job_profile) ? $emp_job_profile->company_emp_device_id	 :  old('company_emp_device_id'))); ?>"  class="form-control form-control-lg" placeholder="Enter company employee device id">
            <?php if($errors->has('company_emp_device_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('company_emp_device_id')); ?></span>
            <?php endif; ?>
        </div>
          
       
        

        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Select Department</label>
            <select class="form-control"  name="department_id">
                <option value="" selected="">Select Department</option>
                <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($depart->id); ?>" <?php echo e((isset($emp_job_profile) ? ($emp_job_profile->department_id  == $depart->id ? 'selected' : '') :  old('department_id') == $depart->id ? 'selected' : '' )); ?>><?php echo e($depart->name); ?>  </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('department_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('department_id')); ?></span>
            <?php endif; ?>
        </div>

       

        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Select Designation</label>
            <select class="form-control"  name="designation_id">
                <option value="" selected="">Select Designation</option>
                <?php $__currentLoopData = $designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($desig->id); ?>" <?php echo e((isset($emp_job_profile) ? ($emp_job_profile->designation_id  == $desig->id ? 'selected' : '') :  old('designation_id') == $desig->id ? 'selected' : '' )); ?>><?php echo e($desig->name); ?>  </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('designation_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('designation_id')); ?></span>
            <?php endif; ?>
        </div>
        
      
        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12">
            <label>Select Organization Role</label>
            <select class="form-control"  name="organization_role_id">
                <option value="" selected="">Select Organization Role</option>
                <?php $__currentLoopData = $organization_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($org_role->id); ?>" <?php echo e((isset($emp_job_profile) ? ($emp_job_profile->organization_role_id   == $org_role->id ? 'selected' : '')  :  old('organization_role_id') == $org_role->id ? 'selected' : '' )); ?>><?php echo e($org_role->name); ?>  </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('organization_role_id')): ?>
                <span class="errr-validation"><?php echo e($errors->first('organization_role_id')); ?></span>
            <?php endif; ?>
        </div>
     
        <div class="form-card-footer card-footer p-t-20 p-0 text-right">
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <a href="" >
                    <button class="theme-btn-outline">cancel</button>
                </a>
            </div>
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <button type="submit"  value="submit" name="submit" class="theme-btn text-white">Save</button>
            </div>
        </div>        
    </div> 
</form>
<?php $__env->startPush('scripts'); ?>
 <script>
    
</script>
 <?php $__env->stopPush(); ?>   <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/organization/job_profile.blade.php ENDPATH**/ ?>