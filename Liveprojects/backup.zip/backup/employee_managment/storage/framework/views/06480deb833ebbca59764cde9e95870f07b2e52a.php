<form id="bank_form_id"  name="bank_form_id" action="<?php echo e(route('organization.bank.add')); ?>"  method="post" enctype="multipart/form-data">
    <div class="form-row">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Account Holder Name</label>
            <input type="text" name="ac_holder_name"  value = "<?php echo e((isset($emp_bank_profile) ? $emp_bank_profile->ac_holder_name :  old('ac_holder_name'))); ?>"  class="form-control form-control-lg" placeholder="Enter Account Holder Name">
            <?php if($errors->has('ac_holder_name')): ?>
                <span class="errr-validation"><?php echo e($errors->first('ac_holder_name')); ?></span>
            <?php endif; ?>
        </div>  
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">

            <label>Bank Name</label>
            <input type="text" name="bank_name"  value = "<?php echo e((isset($emp_bank_profile) ? $emp_bank_profile->bank_name :  old('bank_name'))); ?>"  class="form-control form-control-lg" placeholder="Enter Bank Name">
            <?php if($errors->has('bank_name')): ?>
                <span class="errr-validation"><?php echo e($errors->first('bank_name')); ?></span>
            <?php endif; ?>
        </div>
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Branch Name</label>
            <input type="text" name="branch_name"  value = "<?php echo e((isset($emp_bank_profile) ? $emp_bank_profile->branch_name :  old('branch_name'))); ?>"  class="form-control form-control-lg" placeholder="Enter Branch name">
            <?php if($errors->has('branch_name')): ?>
                <span class="errr-validation"><?php echo e($errors->first('branch_name')); ?></span>
            <?php endif; ?>
        </div>  
      
        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label>Account No</label>
            <input type="text" name="account_no"  value = "<?php echo e((isset($emp_bank_profile) ? $emp_bank_profile->account_no :  old('account_no'))); ?>"  class="form-control form-control-lg" placeholder="Enter Branch name">
            <?php if($errors->has('account_no')): ?>
                <span class="errr-validation"><?php echo e($errors->first('account_no')); ?></span>
            <?php endif; ?>
        </div>

        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
            <label> Ifsc Code</label>
            <input type="text" name="ifsc_code"  value = "<?php echo e((isset($emp_bank_profile) ? $emp_bank_profile->ifsc_code	 :  old('ifsc_code	'))); ?>"  class="form-control form-control-lg" placeholder="Enter ifsc code">
            <?php if($errors->has('ifsc_code')): ?>
                <span class="errr-validation"><?php echo e($errors->first('ifsc_code')); ?></span>
            <?php endif; ?>
        </div>
        
       
        
        
        <div class="form-card-footer card-footer p-t-20 p-0 text-right">
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <a href="" >
                    <button class="theme-btn-outline">cancel</button>
                </a>
            </div>
            <div class="btn-group mr-2" role="group" aria-label="Second group">
                <button type="submit"  value="submit" name="submit" class="theme-btn text-white">Save</button>
            </div>
        </div>        
    </div> 
</form>
<?php $__env->startPush('scripts'); ?>
 <script>
    
</script>
 <?php $__env->stopPush(); ?>   <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/organization/bank.blade.php ENDPATH**/ ?>