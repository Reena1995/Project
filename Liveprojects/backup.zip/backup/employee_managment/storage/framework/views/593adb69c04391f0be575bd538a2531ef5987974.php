

<form  id="emp_emergency_add"  name="emp_emergency_add" action="<?php echo e(route('contact.emergency.add')); ?>"  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        
        <input type="hidden" name="user_id" value="<?php echo e($emp->uuid); ?>">
        <input type="hidden" name="final_submit" value="<?php echo e($submitFinal); ?>">

            <div id="emp_emergency_contact">

                <?php if(count($emergency_details)): ?>
                
                    <?php $__currentLoopData = $emergency_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card education mt-3 emergencyadd">
                
                            <div class="card-body " >
            
                                    <div class="form-row">
                                
                                        <input type="hidden" name="emergency_uuid[]" value="<?php echo e($em->uuid); ?>">

                                        

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Name</label>
                                            <input type="text" value = "<?php echo e($em->name); ?>" name="name[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('name[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('name[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>address</label>
                                            <textarea  class="form-control form-control-lg"  name="address[]" cols="30" placeholder="Enter Details Of disaility">
                                                <?php echo e($em->address); ?>

                                            </textarea>
                                            <?php if($errors->has('address[]')): ?>
                                                <span class="errr-validation"><?php echo e($errors->first('address[]')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                       
                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Relationship</label>
                                            <input type="text" value = "<?php echo e($em->relationship); ?>" name="relationship[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('relationship[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('relationship[]')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                            <label>Contact No</label>
                                            <input type="text" value = "<?php echo e($em->contact_no); ?>" name="contact_no[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                            <?php if($errors->has('contact_no[]')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('contact_no[]')); ?></span>
                                            <?php endif; ?>
                                        </div>



                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                        
                                        </div>

                                    
                                    </div> 
                            </div>   
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?> 

                    <div class="card education mt-3 emergencyadd educationDetails" id="">
            
                        <div class="card-body " >
        
                            <div class="form-row">
                            
                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Name</label>
                                    <input type="text" value = "" name="name[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                    <?php if($errors->has('name[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('name[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>address</label>
                                    <textarea  class="form-control form-control-lg" value="" name="address[]" cols="30" placeholder="Enter Details Of disaility"></textarea>
                                    <?php if($errors->has('address[]')): ?>
                                        <span class="errr-validation"><?php echo e($errors->first('address[]')); ?></span>
                                    <?php endif; ?>
                                </div>
                                        
                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Relationship</label>
                                    <input type="text" value = "" name="relationship[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                    <?php if($errors->has('relationship[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('relationship[]')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    <label>Contact No</label>
                                    <input type="text" value = "" name="contact_no[]" class="form-control form-control-lg" placeholder="Enter University Name">
                                    <?php if($errors->has('contact_no[]')): ?>
                                            <span class="errr-validation"><?php echo e($errors->first('contact_no[]')); ?></span>
                                    <?php endif; ?>
                                </div>


                                <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                    
                                </div> 

                                <div>
                                    <button type="button"  class="btn btn-danger d-none delete">delete</button> 
                                </div>

                            </div> 

                        </div>   
                       
                    </div>
                  

                   
                <?php endif; ?>  
                
                
            </div>
           
            <div class="mt-4"><button type="button"  id="addem" class="btn btn-default pull-left  btn btn-primary mt-2 ">Add</button><br></div>
           
            



            <div class="form-card-footer card-footer p-t-20 p-0 text-right">
                    <div class="btn-group mr-3" role="group" aria-label="Second group">
                        <a href="" >
                            <button class="theme-btn-outline">cancel</button>
                        </a>
                    </div>
                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                        <button type="button" id="emeBtn" class="theme-btn text-white">Save</button>
                    </div>
            </div>     


        </form>

   


<?php $__env->startPush('scripts'); ?>
 <script>
    $(document).ready(function () {

        $("#addem").click(function () { 

            console.log('addemddddd');

            var defaultHtmlAppend = $('.emergencyadd').last().clone();
            console.log(defaultHtmlAppend);
            var rowIndex = $('.emergencyadd').length;  
            console.log(defaultHtmlAppend.find('.education'));

            defaultHtmlAppend.find('input[name]').each(function(){
                var name = $(this).attr('name');
		    	$(this).attr('name',name).val('');
                $(this).parents('.emergencyadd').find('.imageset').remove();
                                    
                $(this).parents('.emergencyadd').append('');
		    }); 
            defaultHtmlAppend.find('textarea').each(function(){
                console.log('textaaaaa');
                var name = $(this).attr('name');
                $(this).attr('name',name).val('');
		    	
                $(this).attr('data-key','certificate_image');
                // $(this).parents('.eduremove').append('');
		    }); 
         
          defaultHtmlAppend.attr('id','educationDetail-'+rowIndex);

            defaultHtmlAppend.find('.btn-danger').removeClass('d-none').attr('data-id',rowIndex);
            $('#emp_emergency_contact').append(defaultHtmlAppend);
        });

        $(document).delegate('.delete','click',function () { 
            var id = $(this).attr('data-id');

            $('#educationDetail-'+id).remove();
            
        });
          

    });
 </script>   
<?php $__env->stopPush(); ?>    <?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/contact/emergency.blade.php ENDPATH**/ ?>