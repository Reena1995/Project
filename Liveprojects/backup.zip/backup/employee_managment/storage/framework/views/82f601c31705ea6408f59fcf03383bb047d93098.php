
     <!-- <div class="col-lg-9 col-md-6 col-sm-12 d-flex"> -->
                            <!-- <div class="tab-content card" id="v-pills-tabContent"> -->
                                <div class="" >
                                    <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="card border-primary mb-3">
                                                        <div class="card-header">Status : </div>
                                                        <div class="card-body text-success">
                                                        <!-- <h5 class="card-title"></h5> -->
                                                        <p class="card-text"><?php echo e($emp->name); ?>'s details successfully added.</p>
                                                        </div>
                                                    </div><!-- /.card -->
                                                </div>
                                            </div>
                                            
                                    </div>
                                </div>
                            <!-- </div> -->
                        <!-- </div>  -->
<?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/contact/final.blade.php ENDPATH**/ ?>