
<?php $__env->startSection('content'); ?>
<section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container-fluid p-t-20">
                    <div class="row d-flex align-items-center">
                        <div class="col-6 m-b-20">
                            <h3>Create a New Employee</h3>
                        </div>
                        
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-md-12 col-12 m-b-30">
                            <!--card begins-->
                            <div class="card m-b-30 add-cards" >
                                <div class="card-header">
                                    <div class="card-title">Add Employee Details</div>
                                </div>
                                <form id="employee_register" action="<?php echo e(route('employee.add')); ?>" name="employee__add_form" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>  
                                    <div class="card-body">    
                                        <div class="form-row row">
                                            <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                <label>First Name</label>
                                                <input type="text" id="first_name_id" name="first_name"  class="form-control form-control-lg" placeholder="Enter First Name" />
                                                
                                                <?php if($errors->has('first_name')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('first_name')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                <label>Last Name</label>
                                                <input type="text" id="last_name_id" name="last_name"  class="form-control form-control-lg" placeholder="Enter Last Name" />
                                               
                                                <?php if($errors->has('last_name')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('last_name')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group floating-label show-label  col-lg-6 col-md-6 col-sm-12">
                                                <label>Company Email Id</label>
                                                <input type="email" id="company_mail_id" name="company_mail"  class="form-control form-control-lg" placeholder="Enter Email Id" />
                                                
                                                <?php if($errors->has('company_mail')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('company_mail')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group floating-label show-label  col-lg-6 col-md-6 col-sm-12">
                                                <label>Mobile No</label>
                                                <input type="text" id="mobile_no_id" name="mobile_no"  class="form-control form-control-lg" placeholder="Enter Mobile No" />
                                                
                                                <?php if($errors->has('mobile_no')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('mobile_no')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="card-footer p-t-20 text-right">
                                                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                                                        <a href="<?php echo e(route('employee.index')); ?>" class="theme-btn-outline">cancel
                                                            </a>
                                                    </div>
                                                    <div class="btn-group" role="group" aria-label="Second group">
                                                        <button type="submit"  value="submit" name="submit" class="theme-btn text-white">Save</button>
                                                    </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
        
       	<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
 <script>
       $(document).ready(function(){
            $("form[name='employee__add_form']").validate({
                rules : {
                    first_name : "required",  
                    last_name : "required",
                    company_mail : "required",  
                    mobile_no : "required",                    
                },
                messages : {
                    first_name : "Please Enter a First Name ",
                    last_name : "Please Enter  a Last Name ",
                    company_mail : "Please Enter an Email Id  ",
                    mobile_no : "Please Enter  a Mobile No ",  
                    
                },
                errorClass: "custom-error",
                errorElement: "div",
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(element).append(error)
                    } else {
                        console.log(element.prev());
                        error.insertAfter(element);
                    }
                },
                submitHandler : function(form){
                    form.submit();
                }
            });
        });
</script>         
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/add.blade.php ENDPATH**/ ?>