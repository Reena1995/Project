<div class="form-row">
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Account Holder</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Account Holder">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Account Number</label>
                                                            <input type="number" class="form-control form-control-lg" placeholder="Enter Account Number">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Bank Name</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Bank Name">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Branch Location</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Branch Location">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Bank Code (IFSC)</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Bank Code (IFSC) ">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Tax Payer ID (PAN)</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Tax Payer ID (PAN)">
                                                        </div>
                                                    </div><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/professional/workexperience.blade.php ENDPATH**/ ?>