
<?php $__env->startSection('content'); ?>
<section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container-fluid p-t-20">
                    <div class="row d-flex align-items-center">
                        <div class="col-6 m-b-20">
                            <h3>Show Document Type</h3>
                        </div>
                        
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-md-12 col-12 m-b-30">
                            <!--card begins-->
                            <div class="card m-b-30 add-cards" >
                                <div class="card-header">
                                    <div class="card-title">Show Document Type Name</div>
                                </div>
                                <form id="document_type_show"  action="" name="document_type_show_form" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>  
                                    <div class="card-body">    
                                        <div class="form-row row">
                                            <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                <label>Document Type </label>
                                                <input type="text" id="document_type" name="document_type" value="<?php echo e($doctype->type); ?>"  class="form-control form-control-lg" placeholder="Enter Document Type" readonly/>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer p-t-20 text-right">
                                                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                                                        <a href="<?php echo e(route('document_type.index')); ?>" class="theme-btn text-white">cancel
                                                            </a>
                                                    </div>
                                        
                                    </div>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
        
       	<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
<script>
       
</script>        
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/document_type/show.blade.php ENDPATH**/ ?>