
        <script src="<?php echo e(asset('console/assets/js/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/popper/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/tbs.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/DataTables/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('console/assets/js/select2/js/select2.min.js')); ?>"></script>
        <!-- validation link -->
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/employee/partial/footer.blade.php ENDPATH**/ ?>