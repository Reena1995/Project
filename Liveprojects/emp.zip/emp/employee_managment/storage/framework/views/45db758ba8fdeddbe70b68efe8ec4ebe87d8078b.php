<div class="form-row">
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="resumefile">Choose Resume</label>
                                                                <input type="file" class="custom-file-input" id="resumefile">
                                                            </div>
                                                            <small class="form-text text-muted mt-3">Remume File Name (ex: Resume-ui-ux-designer.pdf) </small>
                                                        </div>
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="idprooffile">ID Proof</label>
                                                                <input type="file" class="custom-file-input" id="idprooffile">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="offerletterfile">Offer Letter</label>
                                                                <input type="file" class="custom-file-input" id="offerletterfile">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="joiningletterfile">Joining Letter</label>
                                                                <input type="file" class="custom-file-input" id="joiningletterfile">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="agreementletterfile">Agreement Letter</label>
                                                                <input type="file" class="custom-file-input" id="agreementletterfile">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-6 col-md-6 col-sm-12 mt-2">
                                                            <div class="custom-file">
                                                                <label class="custom-file-label" for="experienceletterfile">Experience Letter</label>
                                                                <input type="file" class="custom-file-input" id="experienceletterfile">
                                                            </div>
                                                        </div>
                                                    </div><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/employee/professional/professional.blade.php ENDPATH**/ ?>