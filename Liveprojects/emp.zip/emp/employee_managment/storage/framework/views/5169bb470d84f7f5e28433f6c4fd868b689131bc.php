
<?php $__env->startSection('content'); ?>
<section class="admin-content">
                <!-- BEGIN PlACE PAGE CONTENT HERE -->
                <!--  container or container-fluid as per your need           -->
                <div class="container-fluid p-t-20">
                    <div class="row d-flex align-items-center">
                        <div class="col-6 m-b-20">
                            <h3>Edit Education Level</h3>
                        </div>
                        
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-10 col-md-12 col-12 m-b-30">
                            <!--card begins-->
                            <div class="card m-b-30 add-cards" >
                                <div class="card-header">
                                    <div class="card-title">Edit Education Level  Details</div>
                                </div>
                                <form id="education_level_edit"  action="<?php echo e(route('education_level.update',$edulevel->uuid)); ?>" name="education_level_edit_form" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>  
                                    <div class="card-body">    
                                        <div class="form-row row">
                                            <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                <label>Education Level  Name</label>
                                                <input type="text" id="education_level_name" name="education_level_name"  value="<?php echo e($edulevel->name); ?>" class="form-control form-control-lg" placeholder="Enter Education Levels name" />
                                                <span class="error"></span>
                                                <?php if($errors->has('education_level_name')): ?>
                                                    <span class="errr-validation"><?php echo e($errors->first('education_level_name')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer p-t-20 text-right">
                                                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                                                        <a href="<?php echo e(route('education_level.index')); ?>" class="theme-btn-outline">cancel
                                                            </a>
                                                    </div>
                                                    <div class="btn-group mr-2" role="group" aria-label="Second group">
                                                        <button type="submit"  value="submit" name="submit"class="theme-btn text-white">Save</button>
                                                    </div>
                                        
                                    </div>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END PLACE PAGE CONTENT HERE -->
            </section>
        
       	<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
<script>
         $(document).ready(function(){
            $("form[name='education_level_edit_form']").validate({
                rules : {
                    education_level_name : "required",                    
                },
                messages : {
                    education_level_name : "Please enter a education level name",
                    
                },
                submitHandler : function(form){
                    form.submit();
                }
            });
        });
</script>        
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.common.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reena\Practice\Liveprojects\employee_managment\resources\views/admin/modules/education_level/edit.blade.php ENDPATH**/ ?>