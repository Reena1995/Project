<div class="form-row">
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Employee ID</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Employee ID">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Department</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Department">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Designation</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Designation">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Date Of Joining</label>
                                                            <input type="text" class="theme-date-picker form-control form-control-lg" placeholder="Select Date Of Joining">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Resignation Date</label>
                                                            <input type="text" class="theme-date-picker form-control form-control-lg" placeholder="Select Resignation Date">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Termination Date</label>
                                                            <input type="text" class="theme-date-picker form-control form-control-lg" placeholder="Select Termination Date">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12">
                                                            <label>Credit Leaves </label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Select Credit Leaves">
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                                            <p class="m-0 p-0"><strong>Notes:</strong> Unused leaves for the Employee</p>
                                                        </div>
                                                        <div class="p-t-10 m-b-10 col-12">
                                                            <h5 class="font-weight-semibold">Salary</h5>
                                                        </div>
                                                        <div class="form-group floating-label show-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                                            <label>Employee Type</label>
                                                            <select class="form-control">
                                                                <option selected="">Choose...</option>
                                                                <option>Part Time</option>
                                                                <option>Full Time</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group floating-label col-lg-6 col-md-6 col-sm-12 d-flex align-items-center">
                                                            <label>Salary Amount</label>
                                                            <input type="text" class="form-control form-control-lg" placeholder="Enter Salary Amount">
                                                        </div>
                                                    </div>